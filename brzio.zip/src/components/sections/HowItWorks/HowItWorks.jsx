import Button from '@/components/ui/Button/Button';
import './HowItWorks.css';

export default function HowItWorks() {
  return (
    <section className="how-it-works" id="how-it-works">
      <div className="how-it-works__container">
        <div className="how-it-works__visual">
          <div className="how-it-works__network">
            <div className="how-it-works__ring how-it-works__ring--1" />
            <div className="how-it-works__ring how-it-works__ring--2" />
            <div className="how-it-works__ring how-it-works__ring--3" />
            <div className="how-it-works__center">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="18" fill="var(--primary-color)" />
                <circle cx="20" cy="20" r="8" fill="white" />
                <circle cx="20" cy="20" r="3" fill="var(--primary-color)" />
              </svg>
            </div>
          </div>
        </div>

        <div className="how-it-works__content">
          <p className="how-it-works__label">Технологија зад уредот</p>
          <h2 className="how-it-works__title">Како функционира?</h2>
          <p className="how-it-works__text">
            Apple AirTag ја користи огромната глобална Apple мрежа, составена
            од стотици милиони iPhone уреди. Секој iPhone во близина анонимно
            ја забележува локацијата на вашиот AirTag и ја испраќа до вас —
            без да го знае тоа. Целото тоа е шифрирано и целосно приватно.
          </p>
          <p className="how-it-works__text">
            Дополнително, AirTag емитира Bluetooth сигнал со дострел до{' '}
            <strong>15 метри</strong>. Кога сте блиску до изгубениот предмет,
            можете да го натерате да издаде звук и точно да го лоцирате.
          </p>
          <div className="how-it-works__cta">
            <Button href="#contact">Порачај веднаш</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
