import Navbar from '@/components/sections/Navbar/Navbar';
import Hero from '@/components/sections/Hero/Hero';
import HowToConnect from '@/components/sections/HowToConnect/HowToConnect';
import HowItWorks from '@/components/sections/HowItWorks/HowItWorks';
import ContactForm from '@/components/sections/ContactForm/ContactForm';
import Footer from '@/components/sections/Footer/Footer';

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <HowToConnect />
        <HowItWorks />
        <ContactForm />
      </main>
      <Footer />
    </>
  );
}
