'use client';

import { useState, useEffect } from 'react';
import Button from '@/components/ui/Button/Button';
import './Hero.css';

const slides = [
  {
    preText: 'Престанете да ги барате клучевите и паричникот секој ден.',
    headline: 'Секогаш Лоцирани',
    supportingText: 'IOS Air Tags работат со Apple Find My и даваат точна локација.',
    gradient: 'linear-gradient(135deg, #007aff 0%, #5ac8fa 100%)',
  },
  {
    preText: 'Поголема сигурност кога станува збор за вашето семејство.',
    headline: 'Мир И Контрола',
    supportingText: 'Лесно се ставаат во џеб, ранец или на клучеви.',
    gradient: 'linear-gradient(135deg, #0040dd 0%, #007aff 100%)',
  },
  {
    preText: 'Дополнителна заштита за автомобил и вредни предмети.',
    headline: 'Паметна Заштита',
    supportingText: 'Добијте известување доколку предметот се помести.',
    gradient: 'linear-gradient(135deg, #007aff 0%, #34c759 100%)',
  },
];

export default function Hero() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="hero" id="hero">
      <div className="hero__inner">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`hero__slide ${index === current ? 'hero__slide--active' : ''}`}
          >
            {/* Mobile: text on top */}
            <div className="hero__content">
              <p className="hero__pre-text">{slide.preText}</p>
              <h1 className="hero__headline">{slide.headline}</h1>
              <p className="hero__supporting-text">{slide.supportingText}</p>
              <Button href="#contact">Порачај веднаш</Button>
            </div>

            {/* Image panel */}
            <div className="hero__image" style={{ background: slide.gradient }}>
              <div className="hero__airtag">
                <svg
                  width="120"
                  height="120"
                  viewBox="0 0 120 120"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="60"
                    cy="60"
                    r="56"
                    stroke="rgba(255,255,255,0.6)"
                    strokeWidth="3"
                    fill="rgba(255,255,255,0.12)"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="36"
                    fill="rgba(255,255,255,0.2)"
                  />
                  <circle cx="60" cy="60" r="18" fill="rgba(255,255,255,0.9)" />
                  <circle cx="60" cy="60" r="8" fill="white" />
                  <path
                    d="M60 20 L63 30 L74 27 L68 37 L78 42 L68 45 L70 56 L60 50 L50 56 L52 45 L42 42 L52 37 L46 27 L57 30 Z"
                    fill="rgba(255,255,255,0.4)"
                  />
                </svg>
              </div>
            </div>
          </div>
        ))}

        <div className="hero__dots">
          {slides.map((_, index) => (
            <button
              key={index}
              className={`hero__dot ${index === current ? 'hero__dot--active' : ''}`}
              onClick={() => setCurrent(index)}
              aria-label={`Slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
