'use client';

import { useState, useRef } from 'react';
import ReCAPTCHA from 'react-google-recaptcha';
import emailjs from '@emailjs/browser';
import Input from '@/components/ui/Input/Input';
import Textarea from '@/components/ui/Textarea/Textarea';
import Button from '@/components/ui/Button/Button';
import './ContactForm.css';

const initialState = {
  name: '',
  lastName: '',
  streetAddress: '',
  contactNumber: '',
  message: '',
};

export default function ContactForm() {
  const [form, setForm] = useState(initialState);
  const [recaptchaToken, setRecaptchaToken] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | loading | success | error
  const recaptchaRef = useRef(null);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!recaptchaToken) {
      alert('Ве молиме потврдете дека не сте робот.');
      return;
    }

    setStatus('loading');

    try {
      await emailjs.send(
        process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID,
        process.env.NEXT_PUBLIC_EMAILJS_TEMPLATE_ID,
        {
          from_name: `${form.name} ${form.lastName}`,
          street_address: form.streetAddress,
          contact_number: form.contactNumber,
          message: form.message,
        },
        process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY
      );

      setStatus('success');
      setForm(initialState);
      recaptchaRef.current?.reset();
      setRecaptchaToken(null);
    } catch {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <section className="contact-form" id="contact">
        <div className="contact-form__container">
          <div className="contact-form__success">
            <svg
              width="56"
              height="56"
              viewBox="0 0 56 56"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="28" cy="28" r="28" fill="var(--primary-color)" />
              <path
                d="M16 28 L24 36 L40 20"
                stroke="white"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <h2>Нарачката е примена!</h2>
            <p>Ќе ве контактираме наскоро на бројот кој го оставивте.</p>
            <Button onClick={() => setStatus('idle')}>Нова нарачка</Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="contact-form" id="contact">
      <div className="contact-form__container">
        <p className="contact-form__label">Без загуба на важни предмети</p>
        <h2 className="contact-form__title">Порачај сега</h2>
        <p className="contact-form__subtitle">
          Пополнете ги полињата и ние ќе ве контактираме.
        </p>

        <form className="contact-form__form" onSubmit={handleSubmit} noValidate>
          <div className="contact-form__row">
            <Input
              label="Име"
              name="name"
              required
              value={form.name}
              onChange={handleChange}
              placeholder="Вашето име"
            />
            <Input
              label="Презиме"
              name="lastName"
              required
              value={form.lastName}
              onChange={handleChange}
              placeholder="Вашето презиме"
            />
          </div>

          <Input
            label="Адреса за достава"
            name="streetAddress"
            required
            value={form.streetAddress}
            onChange={handleChange}
            placeholder="Улица, број, град"
          />

          <Input
            label="Контакт број"
            name="contactNumber"
            type="tel"
            required
            value={form.contactNumber}
            onChange={handleChange}
            placeholder="+389 __ ___ ___"
          />

          <Textarea
            label="Порака (незадолжително)"
            name="message"
            value={form.message}
            onChange={handleChange}
            placeholder="Дополнителни информации за нарачката..."
          />

          <div className="contact-form__recaptcha">
            <ReCAPTCHA
              ref={recaptchaRef}
              sitekey={process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY}
              onChange={setRecaptchaToken}
            />
          </div>

          {status === 'error' && (
            <p className="contact-form__error">
              Се случи грешка. Обидете се повторно или јавете се на нашиот
              број.
            </p>
          )}

          <Button type="submit">
            {status === 'loading' ? 'Испраќање...' : 'Испрати нарачка'}
          </Button>
        </form>
      </div>
    </section>
  );
}
