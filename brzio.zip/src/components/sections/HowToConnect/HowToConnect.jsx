import './HowToConnect.css';

const steps = [
  {
    label: 'iPhone',
    description: 'Потребен е iPhone со iOS 14.5 или понова верзија',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="12" y="4" width="24" height="40" rx="5" stroke="currentColor" strokeWidth="2.5" fill="none" />
        <circle cx="24" cy="38" r="2" fill="currentColor" />
        <rect x="20" y="8" width="8" height="2" rx="1" fill="currentColor" />
      </svg>
    ),
  },
  {
    label: 'Bluetooth вклучен',
    description: 'Bluetooth мора да биде активен за да се поврзе уредот',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M24 8 L24 40 M24 8 L34 18 L24 28 L34 38 M24 28 L14 18"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
  {
    label: 'Локација вклучена',
    description: 'Услугите за локација мора да бидат овозможени на уредот',
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M24 4C17.4 4 12 9.4 12 16C12 25 24 44 24 44C24 44 36 25 36 16C36 9.4 30.6 4 24 4Z"
          stroke="currentColor"
          strokeWidth="2.5"
          fill="none"
        />
        <circle cx="24" cy="16" r="5" stroke="currentColor" strokeWidth="2.5" fill="none" />
      </svg>
    ),
  },
];

export default function HowToConnect() {
  return (
    <section className="how-to-connect" id="how-to-connect">
      <div className="how-to-connect__container">
        <p className="how-to-connect__label">Лесно поврзување</p>
        <h2 className="how-to-connect__title">Само 3 работи ви се потребни</h2>
        <div className="how-to-connect__steps">
          {steps.map((step, i) => (
            <div key={i} className="how-to-connect__step">
              <div className="how-to-connect__icon">{step.icon}</div>
              <h3 className="how-to-connect__step-title">{step.label}</h3>
              <p className="how-to-connect__step-desc">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
